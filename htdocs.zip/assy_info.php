﻿<html>
<head charset="shift-JIS">
<title>子ー親検索</title>
</head>
<frameset rows="122,*"> 
<frame src="assy_info_head.php">
<frame src="assy_info_foot.php" name="foot"> 
</frameset> 


</html>