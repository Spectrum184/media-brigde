﻿<html>
<body bgcolor="#bbbbff">
<head charset="Shift_JIS">
<title>加工票出力チェック</title>

<font size=6>＜加工票出力チェック＞</font><br><br>
<form method="post" action="prod_print_cheak.php">
製作指示No<input pattern="[0-9]{9}" title="[0-9]9文字" value="" name="Plan_No_Search" size="8" autofocus>
（バーコードを読込ませてください）<br>
</form>

<?php 
header("Content-Type: text/html;charset=utf8");

//定義ファイルの読込
//MySQL接続用定数の読込
require_once('config.php');
$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

if(!$link)
{
	//DB接続失敗の場合は処理を止める
	die('データベースの接続に失敗しました。<br />
	管理者へ連絡してください。');
}


if(!empty($_POST["Plan_No_Search"]))
{
	$PNoS_array=str_split($_POST["Plan_No_Search"],8);

	$PPNO=$PNoS_array[0];
	$SEQ=$PNoS_array[1];

	$SQL="SELECT COMP_FG,PRNT_FG FROM productplan_details_table 
		where Prod_Plan_No='$PPNO' and Seq_No=$SEQ;";
	if($result=mysqli_query($link,$SQL))
	{
		if(mysqli_num_rows($result)!=0)
		{
			$row = mysqli_fetch_assoc($result);
			if($row['COMP_FG']==1)
			{
				echo'入庫消込済みです。';
			}
			elseif($row['PRNT_FG']==1)
			{
				echo'チェック済みです。';
			}
			else
			{
				$SQL="UPDATE productplan_details_table 
					SET PRNT_FG=1 
					where Prod_Plan_No='$PPNO' and Seq_No=$SEQ;";

					mysqli_query($link,$SQL);
				echo'チェックOK！！';
			}

		}
		else
		{
			echo'データが見つかりません。';
		}
	}
	else
	{
		echo('データ読込に失敗しました');
	}
}
?>
<br>
<table border="1" bgcolor="#999999">
	<tr bgcolor="#cccccc">
		<td width="110"><b>製作指示No.</b></td>
		<td width="80"><b>得意CD</b></td>
		<td width="150"><b>製品・部品番号</b></td>
		<td width="200"><b>名称</b></td>
		<td width="90"><b>工程</b></td>
		<td width="80"><b>指示納期</b></td>
		<td width="70"><b>指示数</b></td>
	</tr>
<?php
$SQL="SELECT pt.Prod_Plan_No as PPNO,Seq_No,pt.Cust_CD AS PT_CCD,Prod_No,Seq_No,Proc_Name,pdt.Req_Due_Date AS PDT_Req_Due_Date,pdt.Prod_Plan_Qty AS PDT_Prod_Plan_Qty,
        Prod_Parts_Name,pdt.Comp_FG AS PDT_C_FG,pdt.PRNT_FG AS PDT_P_FG FROM productplan_details_table as pdt 

left join productplan_table as pt on pt.Prod_Plan_No=pdt.Prod_Plan_No 
left join process_master as pm on pm.Proc_CD=pdt.Proc_CD 
left join product_parts_master as ppm on ppm.Cust_CD=pt.Cust_CD and ppm.Prod_Parts_No=pt.Prod_No 
where pdt.Comp_FG=0 and pdt.PRNT_FG=0 and Prod_No IS NOT NULL;";
if($result=mysqli_query($link,$SQL))
{
	if(mysqli_num_rows($result)!=0)
	{
		while($row = mysqli_fetch_assoc($result))
		{
?>
			<tr bgcolor="#ffff99">
				<td><?=$row['PPNO'].$row['Seq_No']?></td>
				<td><?=$row['PT_CCD']?></td>
				<td><?=$row['Prod_No']?></td>
				<td><?=$row['Prod_Parts_Name']?></td>
				<td><?=$row['Proc_Name']?></td>
				<td><?=$row['PDT_Req_Due_Date']?></td>
				<td align="right"><?=$row['PDT_Prod_Plan_Qty']?></td>
			</tr>
<?php
		}
	}
?>
			</table><br>
<?php
}
?>
</html>