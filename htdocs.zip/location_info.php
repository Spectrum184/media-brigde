﻿<html>
<body bgcolor="#bbbbff">
<center>
<form method="post" action="location_info.php">
<font size=5>＜ロケーションメンテ＞</font><br>
得意先CD<input type="text" value="<?php 
if(!empty($_POST["Cust_CD_Search"]))
{
	echo $_POST["Cust_CD_Search"];
}
?>" name="Cust_CD_Search" size="4">&nbsp;
製品番号<input type="text" value="<?php 
if(!empty($_POST["Prod_No_Search"]))
{
	echo $_POST["Prod_No_Search"];
}
?>" name="Prod_No_Search" size="30">
<input type="submit" value="検索">
</form>

<?php
if(!empty($_POST["okmsg"]))
{
	die ('登録OK!!');
}
if(!empty($_POST["Cust_CD_Search"]) and !empty($_POST["Prod_No_Search"]))
{
	$Cust_CD_Search=$_POST["Cust_CD_Search"];
	$Prod_No_Search=$_POST["Prod_No_Search"];
	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');
	$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

	if(!$link)
	{
		//DB接続失敗の場合は処理を止める
		die('データベースの接続に失敗しました。<br />
		管理者へ連絡してください。');
	}
	//入力された品番が製品マスターにあるかチェック
	$SQL="SELECT Prod_Parts_Name FROM product_parts_master 
	where Cust_CD='$Cust_CD_Search' and Prod_Parts_No='$Prod_No_Search';";
	$result=mysqli_query($link,$SQL);

	if(mysqli_num_rows($result)==0)
	{
		die ('入力した番号は未登録です。');
	}

	$SQL="SELECT Rank_No,Location FROM location_master 
	where Cust_CD='$Cust_CD_Search' and Parts_No='$Prod_No_Search' 
        order by Rank_No;";
	if($result=mysqli_query($link,$SQL))
	{
?>
		<form method="post" action="location_update.php">
		<table border="1">
		<tr bgcolor="#999999">
		<td width="50"></td>
		<td width="130">ロケーションNo</td>
		</tr>

<?php
		$Icnt=1;
		while($row = mysqli_fetch_assoc($result)) 
		{
			if($Icnt==1)
			{
?>
			<tr bgcolor="#ff00ff">
			<td>
<?php
				echo 'メイン';
			}
			else
			{
?>
			<tr bgcolor="#ffffff">
			<td>
<?php
				echo 'サブ';
			}
			while($Icnt!=$row['Rank_No'])
			{
?>

				</td><td>
				<input type="text" value="" name="Location<?=$Icnt?>">
				</td></tr>
				<tr><td bgcolor="#ffffff">サブ
<?php
				$Icnt=$Icnt+1;
			}			
?>
			</td>
			<td>
			<input type="text" value="<?=$row['Location']?>" 
				name="Location<?=$Icnt?>">
			</td>
			</tr>
<?php
			$Icnt=$Icnt+1;
		}
		while($Icnt<=5)
		{

			if($Icnt==1)
			{
?>
				<tr bgcolor="#ff00ff">
				<td>メイン</td>
<?php
			}
			else
			{
?>
				<tr>
				<td bgcolor="#ffffff">サブ</td>
<?php
			}
?>
			<td><input type="text" value="" name="Location<?=$Icnt?>"></td>
			</tr>
<?php
			$Icnt=$Icnt+1;
		}
?>
		</table><br>
		<input type="hidden" name="Cust_CD" value="<?php echo $Cust_CD_Search; ?>">
		<input type="hidden" name="Parts_No" value="<?php echo $Prod_No_Search; ?>">		
		<!--Enter	Keyによるsubmitを不可、登録ボタンクリックのみsubmit-->
		<input type="button" value="登録" onclick="submit();">
		</form>
<?php
	}
	else
	{
		echo'データが見つかりません。';
	}
}
?>
</center>
</html>