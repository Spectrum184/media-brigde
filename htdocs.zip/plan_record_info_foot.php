﻿<html>

<body bgcolor="#bbbbff">
	<center>

		<?php
		header("Content-Type: text/html;charset=charset=utf8");

		if (!empty($_POST["Cust_CD_Search"]) and !empty($_POST["Prod_No_Search"])) {
			$Cust_CD_Search = $_POST["Cust_CD_Search"];
			$Prod_No_Search = $_POST["Prod_No_Search"];

		?>

			<head charset="shift-JIS">


				<?php
				//定義ファイルの読込
				//MySQL接続用定数の読込
				require_once('config.php');
				$link = mysqli_connect(HOST_NAME, USER_ID, PASS, DB_NAME_PROD);

				if (!$link) {
					die('データベースの接続に失敗しました。');
				}
				$SQL = "SELECT PT.Prod_Plan_No as PP_No,Entry_Date,PT.Comp_FG as PTC_FG,Seq_No,Abbre_Proc_Name,PTD.Prod_Plan_Qty as PTD_PP_QTY,
PTD.Req_Due_Date as PTD_RD_DATE,
PTD.Comp_Qty as PTDC_QTY,PTD.Comp_Date as PTDC_DATE,PTD.Comp_FG as PTDC_FG FROM ((productplan_table as PT
left join (SELECT Prod_Plan_No,MAX(PRNT_FG) as PTPC_FG FROM productplan_details_table GROUP BY Prod_Plan_No) AS PTP
on PT.Prod_Plan_No=PTP.Prod_Plan_No)
left join productplan_details_table as PTD on PT.Prod_Plan_No=PTD.Prod_Plan_No)
left join process_master as PM on PTD.Proc_CD=PM.Proc_CD
where Cust_CD='$Cust_CD_Search' and Prod_No='$Prod_No_Search' and PTPC_FG=1
order by PP_No DESC;";
				if ($result = mysqli_query($link, $SQL)) {
					$W_PLAN_NO = '';
					while ($row = mysqli_fetch_assoc($result)) {
						if ($W_PLAN_NO != $row['PP_No']) {
							if ($W_PLAN_NO != '') {
				?>
								</tr>
								</table>
							<?php
							}
							?>
							<table border="0">
								<tr>
									<td>
										<table border="1" bgcolor="#999999">
											<tr bgcolor="#cccccc">
												<td>指示No&日</td>
											</tr>
											<tr>
												<td bgcolor="#ffffe0"><?= $row['PP_No'] ?></td>
											</tr>
											<tr>
												<td bgcolor="#ffffe0"><?= $row['Entry_Date'] ?></td>
											</tr>
										</table>
									<?php
								}
									?>
									<td>
										<table border="1" bgcolor="#999999">
											<tr bgcolor="#cccccc">
												<td>工程<?= $row['Seq_No'] ?></td>
												<td><?= $row['Abbre_Proc_Name'] ?></td>
											</tr>
											<tr>
												<td bgcolor="#00ff7f"><?= $row['PTD_RD_DATE'] ?></td>
												<?php
												if ($row['PTDC_FG'] == '1') {
												?>
													<td bgcolor="#ffb6c1"><?= $row['PTDC_DATE'] ?></td>
													<?php
												} else {
													if ($row['PTC_FG'] != '1') {
													?>
														<td bgcolor="#ffffff"></td>
													<?php
													} else {
													?>
														<td bgcolor="#ff0000"></td>
												<?php
													}
												}
												?>
											</tr>
											<tr>
												<td width="90" align="right" bgcolor="#00ff7f"><?= $row['PTD_PP_QTY'] ?></td>
												<?php
												if ($row['PTDC_FG'] == '1') {
												?>
													<td width="90" align="right" bgcolor="#ffb6c1"><?= $row['PTDC_QTY'] ?></td>
													<?php
												} else {
													if ($row['PTC_FG'] != '1') {
													?>
														<td width="90" align="right" bgcolor="#ffffff"></td>
													<?php
													} else {
													?>
														<td width="90" align="right" bgcolor="#ff0000"></td>
												<?php
													}
												}
												?>
											</tr>
										</table>
									</td>
								<?php
								$W_PLAN_NO = $row['PP_No'];
							}
								?>
								</tr>
							</table>
					<?php
				}
			}
					?>
	</center>

</html>