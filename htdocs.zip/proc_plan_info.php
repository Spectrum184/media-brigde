﻿<html>
<head charset="shift-JIS">
<title>工程別製作指示状況</title>
</head>
<frameset rows="122,*"> 
<frame src="proc_plan_info_head.php"> 
<frame src="proc_plan_info_foot.php" name="foot"> 
</frameset> 


</html>