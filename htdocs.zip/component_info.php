﻿<html>
<head charset="shift-JIS">
<title>構成品在庫状況</title>
</head>
<frameset rows="156,*"> 
<frame src="component_info_head.php" name="head"> 
<frame src="component_info_foot.php" name="foot"> 
</frameset> 


</html>