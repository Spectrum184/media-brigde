<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./asets/main.css">
</head>
<body>
     <h1 class="heading">図面検索</h1> 
     <form class="form">
     <div class="header_search">
         <input type="text" class="search_input" placeholder="入力してください">
         <button class="search_input_btn">検索</button>
     </div>
    </form>
     <table border="1">
         <tr>
             <th>ID （ずめん) </th>
            <th>図面番号</th>
            <th>名称</th>
            <th>設変</th>
            <th>得意先</th>
            <th>登録日</th>
            <th>更新日</th>
         </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>
        <tr>
            <td>16688 </td>
            <td>ML259688 </td>
            <td>GRIP,FRONT PILLAR LH </td>
            <td>F </td>
            <td>5001 </td>
            <td>2015/05/25</td>
            <td>2020/05/25</td>
        </tr>


     </table>
</body>
</html>