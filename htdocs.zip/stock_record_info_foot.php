﻿<html>
<body bgcolor="#bbbbff">
<center>
<?php
if(!empty($_POST["Cust_CD_Search"]) and $_POST["Prod_No_Search"]!="")
{
	$Cust_CD_Search=$_POST["Cust_CD_Search"];
	$Prod_No_Search=$_POST["Prod_No_Search"];	

	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');



$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

if(!$link)
{
	die('データベースの接続に失敗しました。');	
}
?>
<head charset="shift-JIS">
<table border="1" bgcolor="#999999">

<?php 
$SQL="SELECT * FROM stock_record_table 
where Cust_CD='$Cust_CD_Search' and Prod_Parts_No='$Prod_No_Search' 
Order by Record_Time DESC;";
if($result=mysqli_query($link,$SQL))
{
	while($row = mysqli_fetch_assoc($result)) 
	{
?>
	<tr bgcolor="#ffffff">
		<td width="160"><?=$row['Record_Time']?></td>
		<td width="65"><?=$row['Cust_CD']?></td>
		<td width="180"><?=$row['Prod_Parts_No']?></td>
		<td width="60">
<?php
		if($row['Proc_Div']=='U')
		{
			echo '出荷';
		}
		elseif($row['Proc_Div']=='I')
		{
			echo '入出庫';
		}
		elseif($row['Proc_Div']=='Z')
		{
			echo '在庫調';
		}
		?></td>
		<td width="60">
<?php
		if($row['In_Out_Div']=='I')
		{
			echo '入庫';
		}
		elseif($row['In_Out_Div']=='O')
		{
			echo '出庫';
		}
		?></td>
		<td width="60" align="right"><?=$row['In_Out_Qty']?></td>
		<td width="60" align="right"><?=$row['Thattime_Stock']?></td>
		<td width="65"><?=$row['R_Cust_CD']?></td>
		<td width="180"><?=$row['R_Prod_Parts_No']?></td>
	</tr>
<?php 
	}
?>
</table>
<?php 
	mysqli_free_result($result);
}
}
?>
</center>
</html>