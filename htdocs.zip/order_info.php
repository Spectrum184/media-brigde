﻿<html>
<head charset="shift-JIS">
<title>製品受注状況</title>
</head>
<frameset rows="122,*"> 
<frame src="order_info_head.php"> 
<frame src="order_info_foot.php" name="foot"> 
</frameset> 


</html>