﻿<html>
<head charset="shift-JIS">
<title>入出庫履歴</title>
</head>
<frameset rows="122,*"> 
<frame src="stock_record_info_head.php"> 
<frame src="stock_record_info_foot.php" name="foot"> 
</frameset> 


</html>