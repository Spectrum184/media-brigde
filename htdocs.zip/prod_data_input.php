﻿<html>
<body bgcolor="#bbbbff">
<head charset="Shift_JIS">
<title>バーコード消込入庫</title>
<font size=6>＜バーコード消込＞</font><br><br>

<table border="1" bgcolor="#999999">
<tr>
	<td bgcolor="#cccccc"><b>製作指示No</b></td>
	<td bgcolor="#ffff99"><b><?php echo $_POST["Plan_No_Search"]; ?></b></td>
</tr>
</table>
<br>
<?php 
header("Content-Type: text/html;charset=utf8");
if(!empty($_POST["Plan_No_Search"]))
{
	$PNoS_array=str_split($_POST["Plan_No_Search"],8);

	$PPNO=$PNoS_array[0];
	$SEQ=$PNoS_array[1];
	
	if(!empty($_POST["Comp_Qty_Input"]))
	{
		$IQTY=$_POST["Comp_Qty_Input"];
	}	

	if(isset($_POST["INPUT_CHEAK"]))
	{	
		if($_POST["INPUT_CHEAK"]=='0')
		{
?>
		<body onLoad="document.F_UPDATE.submit();">
		<form method="post" action="prod_data_update.php" name="F_UPDATE">
		<input type="hidden" name="PP_NO" value="<?php echo $PPNO; ?>">
		<input type="hidden" name="SQ_NO" value="<?php echo $SEQ; ?>">
		<input type="hidden" name="Comp_Qty_Input" value="<?php echo $IQTY; ?>">
		</form>
		</body>
		</html>
<?php
		}
		elseif($_POST["INPUT_CHEAK"]!='')
		{
			$IQTY=NULL;
		}
	}

	
	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');
	$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

	if(!$link)
	{
?>
		<button onclick="location.href='prod_data_search.php'">戻る</button><br>
<?php
		//DB接続失敗の場合は処理を止める
		die('データベースの接続に失敗しました。<br />
		管理者へ連絡してください。');
	}


	
	$SQL="SELECT pt.Cust_CD AS PT_CCD,Prod_No,Seq_No,Proc_Name,pdt.Req_Due_Date AS PDT_Req_Due_Date,pdt.Prod_Plan_Qty AS PDT_Prod_Plan_Qty,
        Prod_Parts_Name,pdt.Comp_FG AS PDT_C_FG FROM productplan_details_table as pdt
 
	left join productplan_table as pt on pt.Prod_Plan_No=pdt.Prod_Plan_No
 
	left join process_master as pm on pm.Proc_CD=pdt.Proc_CD
 
	left join product_parts_master as ppm on ppm.Cust_CD=pt.Cust_CD and ppm.Prod_Parts_No=pt.Prod_No 
	where pdt.Prod_Plan_No='$PNoS_array[0]' and Seq_No=$PNoS_array[1] and Prod_No IS NOT NULL;";
	if($result=mysqli_query($link,$SQL))
	{
		if(mysqli_num_rows($result)!=0)
		{
			$row = mysqli_fetch_assoc($result);
?>
			<table border="1" bgcolor="#999999">
			<tr bgcolor="#cccccc">
				<td width="80"><b>得意CD</b></td>
				<td width="150"><b>製品・部品番号</b></td>
				<td width="200"><b>名称</b></td>
			</tr>
			<tr bgcolor="#ffff99">
				<td><?=$row['PT_CCD']?></td>
				<td><?=$row['Prod_No']?></td>
				<td><?=$row['Prod_Parts_Name']?></td>
			</tr>
			</table><br><br>
			<table border="1" bgcolor="#999999">
			<tr bgcolor="#cccccc">
				<td width="90"><b>工程</b></td>
				<td width="80"><b>指示納期</b></td>
				<td width="70"><b>指示数</b></td>
			</tr>
			<tr bgcolor="#ffff99">
				<td><?=$row['Proc_Name']?></td>
				<td><?=$row['PDT_Req_Due_Date']?></td>
				<td align="right"><?=$row['PDT_Prod_Plan_Qty']?></td>
			</tr>
			</table><br><br>
			<table border="1" bgcolor="#999999">
			<tr bgcolor="#cccccc">
				<td width="90"><b>前工程</b></td>
				<td width="80"><b>前完日</b></td>
				<td width="70"><b>前完数</b></td>
				<td width="90"><b>後工程</b></td>
			</tr>
			<tr bgcolor="#ffff99">
<?php 
			//前工程状態読込
			$SQL="SELECT Proc_Name,Prod_Plan_Qty,Req_Due_Date,Comp_Qty,Comp_Date,Comp_FG FROM productplan_details_table as pdt
			left join process_master as pm on pm.Proc_CD=pdt.Proc_CD
 
			where Prod_Plan_No='$PNoS_array[0]' and Seq_No=$PNoS_array[1]-1;"; 
			if($result=mysqli_query($link,$SQL))
			{
				//読込データの有無をチェック
				if(mysqli_num_rows($result)!=0)
				{
					$row1 = mysqli_fetch_assoc($result);
?>
					<td><?=$row1['Proc_Name']?></td>
					<td><?=$row1['Comp_Date']?></td>
					<td><?=$row1['Comp_Qty']?></td>
<?php
				}
				else
				{
?>
					<td>-</td>
					<td>-</td>
					<td>-</td>
<?php
				}
			}
			else
			{
				echo'前工程テータ読込失敗';
			}
			//後工程状態読込
			$SQL="SELECT Proc_Name FROM productplan_details_table as pdt
			left join process_master as pm on pm.Proc_CD=pdt.Proc_CD
 
			where Prod_Plan_No='$PNoS_array[0]' and Seq_No=$PNoS_array[1]+1;"; 
			if($result=mysqli_query($link,$SQL))
			{
				//読込データの有無をチェック
				if(mysqli_num_rows($result)!=0)
				{
					$row2 = mysqli_fetch_assoc($result);		
?>
					<td><?=$row2['Proc_Name']?></td>
<?php
				}
				else
				{
?>
					<td>-</td>
<?php
				}
			}
			else
			{
				echo'後工程テータ読込失敗';
			}
?>
			</tr>
			</table><br><br>
<?php
			if($row['PDT_C_FG']==1)
			{
				echo'入庫消込済みです。';
	
			}
			elseif($row['Seq_No']==1 or $row1['Comp_FG']==1)
			{
				if(empty($IQTY))
				{
?>
					<table border="1" bgcolor="#999999">
					<tr>
						<td bgcolor="#cccccc"><b>完成数？</b></td>
						<td>
						<form method="post" action="prod_data_input.php">
						<input type="hidden" name="Plan_No_Search" value="<?php echo $_POST["Plan_No_Search"]; ?>">
						<input pattern="^[0-9]+$" title="半角数値" value="" name="Comp_Qty_Input" size="8" autofocus>
						</form>
						</td>
					</tr>
					</table>
					(完成値を入力後、Enterキーを押してください。)<br>
<?php
				}
				else
				{
?>
					<table border="1" bgcolor="#999999">
					<tr>
						<td bgcolor="#cccccc"><b>完成数？</b></td>
						<td align="right" bgcolor="#ffff00" width="80"><?php echo $IQTY; ?></td>
					</tr>
					</table><br>
					上記の数量で入庫します。よろしいですか？<br>
					OK=0,NG=1～9（入力後、Enterキーを押してください。）<br>
					<form method="post" action="prod_data_input.php">
					<input type="hidden" name="Plan_No_Search" value="<?php echo $_POST["Plan_No_Search"]; ?>">
					<input type="hidden" name="Comp_Qty_Input" value="<?php echo $IQTY; ?>">
					<input pattern="[0-9]" title="[0-9]" value="" name="INPUT_CHEAK" size="1" autofocus>
					</form>
<?php
				}
			}
			else
			{
				echo'前工程未完了です。';
			}
		}
		else
		{
			echo'データが見つかりません。';
		}
 		mysqli_free_result($result);

	}
	else
	{
		echo'エラー';
	}
}
?>
<button onclick="location.href='prod_data_search.php'">戻る</button>
</html>