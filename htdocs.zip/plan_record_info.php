﻿<html>
<head charset="shift-JIS">
<title>製作指示状況＆履歴</title>
</head>
<frameset rows="186,*"> 
<frame src="plan_record_info_head.php" name="head"> 
<frame src="plan_record_info_foot.php" name="foot"> 
</frameset> 


</html>