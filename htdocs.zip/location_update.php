﻿<?php
$CUST_CD=$_POST["Cust_CD"];
//大文字に変換
$PARTS_NO=strtoupper($_POST["Parts_No"]);

require_once('config.php');

$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

$Icnt=1;
while($Icnt<=5)
{
	if(empty($_POST["Location$Icnt"]))
	{
		$SQL="SELECT Location FROM location_master 
		WHERE Cust_CD='{$CUST_CD}' AND Parts_No='{$PARTS_NO}' AND Rank_No=$Icnt;";
		$result=mysqli_query($link,$SQL);

		//SELECT結果が0件かどうか判定
		if(mysqli_num_rows($result)!=0)
		{
			$SQL="DELETE FROM location_master 
			WHERE Cust_CD='{$CUST_CD}' AND Parts_No='{$PARTS_NO}' AND Rank_No=$Icnt;";
			mysqli_query($link,$SQL);
		}
	}
	else
	{
		$SQL="SELECT Location FROM location_master 
		WHERE Cust_CD='{$CUST_CD}' AND Parts_No='{$PARTS_NO}' AND Rank_No=$Icnt;";
		$result=mysqli_query($link,$SQL);

		if(mysqli_num_rows($result)==0)
		{
			$SQL="INSERT INTO location_master 
			VALUE ('{$CUST_CD}','{$PARTS_NO}',$Icnt,'{$_POST["Location$Icnt"]}');";
			mysqli_query($link,$SQL);
		}
		else
		{
			$SQL="UPDATE location_master 
			SET location='{$_POST["Location$Icnt"]}'
			WHERE Cust_CD='{$CUST_CD}' AND Parts_No='{$PARTS_NO}' AND Rank_No=$Icnt;";
			mysqli_query($link,$SQL);
		}
	}
	$Icnt=$Icnt+1;
}
?>

<body onLoad="document.formName.submit();">

<form action="location_info.php" method="post" name="formName">
<input type="hidden" name="okmsg" value="OK">
<input type="hidden" name="Cust_CD_Search" value="<?php echo $CUST_CD; ?>">
<input type="hidden" name="Prod_No_Search" value="<?php echo $PARTS_NO; ?>">
</form>

</body>		