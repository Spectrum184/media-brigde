﻿<html>
<body bgcolor="#bbbbff">
<head charset="Shift_JIS">
<title>バーコード消込入庫</title>

<font size=6>＜バーコード消込＞</font><br><br>
<form method="post" action="prod_data_input.php">
製作指示No<input pattern="[0-9]{9}" title="[0-9]9文字" value="" name="Plan_No_Search" size="8" autofocus>
（バーコードを読込ませてください）<br><br>

</form>
<?php
if(!empty($_POST["okmsg"]))
{
	if($_POST["okmsg"]=="OK")
	{
		echo '入力処理OK!!';	
	}
}
?>
</html>