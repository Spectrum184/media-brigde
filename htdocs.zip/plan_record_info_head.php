﻿<html>
<body bgcolor="#bbbbff">
<center>
<form method="post" action="plan_record_info_head.php" target="head">
<font size=5>＜製作指示状況＆履歴＞</font><br>
得意先CD<input type="text" value="<?php 
if(!empty($_POST["Cust_CD_Search"]))
{
	echo $_POST["Cust_CD_Search"];
}
?>" name="Cust_CD_Search" size="3" style="font-size:20px;">&nbsp;
製品番号<input type="text" value="<?php 
if(!empty($_POST["Prod_No_Search"]))
{
	echo $_POST["Prod_No_Search"];
}
?>" name="Prod_No_Search" size="30" style="font-size:20px;">
<input type="submit" value="検索">
</form>

<?php
if(!empty($_POST["Cust_CD_Search"]) and $_POST["Prod_No_Search"]!="")
{
	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');
	$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);
	if(!$link)
	{
		die('データベースの接続に失敗しました。');	
	}

	$SQL="SELECT Prod_Parts_Name,stock,L_StkIn_Date,L_StkOut_Date FROM product_parts_master 
	left join unitsinstock_table on unitsinstock_table.Cust_CD=product_parts_master.Cust_CD and Prod_Parts_No=Prod_No and Prod_Div='0' 
	where product_parts_master.Cust_CD='{$_POST["Cust_CD_Search"]}' and Prod_Parts_No='{$_POST["Prod_No_Search"]}';";
	if($result=mysqli_query($link,$SQL))
	{
		if(mysqli_num_rows($result)!=0)
		{
			$row = mysqli_fetch_assoc($result)
?>

			<table border="1" bgcolor="#999999">
			<tr>
				<td bgcolor="#cccccc" width="80">部品名称</td>
				<td bgcolor="#ffffff" width="220"><?=$row['Prod_Parts_Name']?></td>
				<td bgcolor="#cccccc" width="40">在庫</td>
				<td bgcolor="#ffffff" width="60" align="right"><?=$row['stock']?></td>
				<td bgcolor="#cccccc" width="80">最終入庫</td>
				<td bgcolor="#ffffff" width="90"><?=$row['L_StkIn_Date']?></td>
				<td bgcolor="#cccccc" width="80">最終出庫</td>
				<td bgcolor="#ffffff" width="90"><?=$row['L_StkOut_Date']?></td>
			</tr>
			</table>

			<table border="1" bgcolor="#999999">
			<tr>
			<td bgcolor="#cccccc">現加工工程</td>
<?php
			$SQL="SELECT Abbre_Proc_Name FROM prod_process_master LEFT JOIN process_master 
			ON prod_process_master.Proc_CD=process_master.Proc_CD 
			WHERE Cust_CD='{$_POST["Cust_CD_Search"]}' and Parts_No='{$_POST["Prod_No_Search"]}';";
			if($result=mysqli_query($link,$SQL))
			{
				if(mysqli_num_rows($result)!=0)
				{
					while($row = mysqli_fetch_assoc($result)) 
					{
?>
						<td bgcolor="#ffffff" width="100"><?=$row['Abbre_Proc_Name']?></td>
<?php			
					}
				}
				else
				{
?>
						<td bgcolor="#ffffff" width="100">未定義</td>
<?php	
					
				}		
			}
			else
			{
				echo'工程読込エラー';
			}
?>
			</td>
			</tr>
			</table>

			<head charset="shift-JIS">
			<table border="0">
			<tr bgcolor="#cccccc">
				<td bgcolor="#00ff7f">加工要期</td>
				<td bgcolor="#00ff7f">加工指示数</td>
				<td bgcolor="#ffb6c1">実加工日</td>
				<td bgcolor="#ffb6c1">実加工数</td>
				<td bgcolor="#ff0000">取消</td>
			</tr>
			</table>

<?php
		}
		else
		{
			echo'データが見つかりません。';
		}
	}
}
?>

	<body onLoad="document.formName.submit();">

	<form method="post" action="plan_record_info_foot.php" target="foot" name="formName">
	<input type="hidden" name="Cust_CD_Search" value="<?php echo $_POST["Cust_CD_Search"]; ?>">
	<input type="hidden" name="Prod_No_Search" value="<?php echo $_POST["Prod_No_Search"]; ?>">
	</form>

	</body>

</center>
</html>