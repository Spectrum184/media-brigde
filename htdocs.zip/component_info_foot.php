﻿<html>
<body bgcolor="#bbbbff">
<center>

<?php 
header("Content-Type: text/html;charset=charset=utf8");

if(!empty($_POST["Cust_CD_Search"]) AND !empty($_POST["Prod_No_Search"]))
{
	$Cust_CD_Search=$_POST["Cust_CD_Search"];
	$Prod_No_Search=$_POST["Prod_No_Search"];
?>
<head charset="shift-JIS">
<table border="1" bgcolor="#999999">
<tr bgcolor="#cccccc">

<?php
function cool_component($Cust_CD_Search,$Prod_No_Search,$space)
{
	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');
	$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

	if(!$link)
	{
		die('データベースの接続に失敗しました。');	
	}
 
	$SQL="SELECT Parts_Cust_CD,Parts_No,Prod_Parts_Name,Product_div,Used_Qty,stock,L_StkIn_Date,L_StkOut_Date FROM (component_master 
	left join product_parts_master on Cust_CD=Parts_Cust_CD and Prod_Parts_No=Parts_No) 
	left join unitsinstock_table on unitsinstock_table.Cust_CD=Parts_Cust_CD and Parts_No=Prod_No 
	where Assy_Cust_CD='$Cust_CD_Search' and Assy_No='$Prod_No_Search';";
	if($result=mysqli_query($link,$SQL))
	{
		$space=$space+2;
		while($row = mysqli_fetch_assoc($result)) 
		{
			//支給品は黄色表示
			if($row['Product_div']=="S2")
			{
?>			
				<tr bgcolor="#ffff00">
<?php
			}
			else
			{
?>
				<tr bgcolor="#ffffff">
<?php
			}
?>			
			<td width="200">
<?php
			//階層が下がるごとに品番の前にスペースを入力
			$spp=$space;
			while($spp>0)
			{
?>
				&nbsp;
<?php
				$spp=$spp-1;
			}
			echo $row['Parts_No'];
?>
			</td>
			<td width="220"><?=$row['Prod_Parts_Name']?></td>
			<td width="60" align="right"><?=$row['Used_Qty']?></td>
			<td width="60" align="right"><?=$row['stock']?></td>
			<td width="90"><?=$row['L_StkIn_Date']?></td>
			<td width="90"><?=$row['L_StkOut_Date']?></td>
			<td width="120">
<?php
			//ロケーション取得
			$SQL="SELECT Location FROM location_master 
			where Cust_CD='{$row['Parts_Cust_CD']}' and Parts_No='{$row['Parts_No']}';";
			if($result2=mysqli_query($link,$SQL))
			{
				while($row2= mysqli_fetch_assoc($result2))
				{
					echo $row2['Location'];
				}
			}
?>
			</td>
			<td width="120">
<?php
			//最終工程取得
			$SQL="SELECT Abbre_Proc_name FROM prod_process_master as ppm

			inner join (SELECT Cust_CD,Parts_NO,Max(Proc_No) as MAX_P_NO FROM prod_process_master

			group by Cust_CD,Parts_NO) as s1 
on ppm.Cust_CD=s1.Cust_CD and ppm.Parts_NO=s1.Parts_NO and ppm.Proc_No=s1.MAX_P_NO

			left join process_master on ppm.Proc_CD=process_master.Proc_CD
			WHERE ppm.Cust_CD='{$row['Parts_Cust_CD']}' and ppm.Parts_NO='{$row['Parts_No']}';";
			if($result3=mysqli_query($link,$SQL))
			{
				while($row3= mysqli_fetch_assoc($result3))
				{
					echo $row3['Abbre_Proc_name'];
				}
			}

?>
			</td>
			<td width="320">
<?php
			//仕掛状況取得
			$PROD_STAT="";
			$SQL="SELECT Req_Due_Date,Prod_Plan_Qty FROM productplan_table 
			where Cust_CD='{$row['Parts_Cust_CD']}' and Prod_No='{$row['Parts_No']}' and Comp_FG!=1;";
			if($result1=mysqli_query($link,$SQL))
			{
				while($row1= mysqli_fetch_assoc($result1))
				{
					if(empty($PROD_STAT))
					{ 
						$PROD_STAT=date("m-d",strtotime($row1['Req_Due_Date']))."/".$row1['Prod_Plan_Qty'];
					}
					else
					{
						$PROD_STAT=$PROD_STAT." ".date("m-d",strtotime($row1['Req_Due_Date']))."/".$row1['Prod_Plan_Qty'];	
					}
				}
				echo $PROD_STAT;
			}			
?>
			</td>
			</tr>			
<?php
		//再帰処理	
		cool_component($row['Parts_Cust_CD'],$row['Parts_No'],$space); 
		}
		mysqli_free_result($result);
	}
}
$space=-1;
cool_component($Cust_CD_Search,$Prod_No_Search,$space);

?>
</table>
<?php 
}
?>
</center>
</html>