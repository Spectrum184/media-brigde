﻿<html>
<body bgcolor="#bbbbff">
<center>

<?php 
header("Content-Type: text/html;charset=charset=utf8");

if(!empty($_POST["Cust_CD_Search"]) and $_POST["Prod_No_Search"]!="")
{
	$Cust_CD_Search=$_POST["Cust_CD_Search"];
	$Prod_No_Search=$_POST["Prod_No_Search"];
?>
<head charset="shift-JIS">
<table border="1" bgcolor="#999999">
<tr bgcolor="#cccccc">

<?php
function cool_component($Cust_CD_Search,$Prod_No_Search,$space)
{
	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');
	$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

	if(!$link)
	{
		die('データベースの接続に失敗しました。');	
	}
 
	$SQL="SELECT Assy_Cust_CD,Assy_No,Prod_Parts_Name,Used_Qty,stock,L_StkIn_Date,L_StkOut_Date,St_Rev_Date FROM (component_master 
	left join product_parts_master on Cust_CD=Assy_Cust_CD and Prod_Parts_No=Assy_No) 
	left join unitsinstock_table on unitsinstock_table.Cust_CD=Assy_Cust_CD and Assy_No=Prod_No 
	where Parts_Cust_CD='$Cust_CD_Search' and component_master.Parts_No='$Prod_No_Search';";
	if($result=mysqli_query($link,$SQL))
	{
		$space=$space+2;
		while($row = mysqli_fetch_assoc($result)) 
		{
?>
			<tr bgcolor="#ffffff">
			<td width="200">
<?php
			//階層が下がるごとに品番の前にスペースを入力
			$spp=$space;
			while($spp>0)
			{
?>
				&nbsp;
<?php
				$spp=$spp-1;
			}
			echo $row['Assy_No'];
?>
			</td>
			<td width="220"><?=$row['Prod_Parts_Name']?></td>
			<td width="40" align="right"><?=$row['Used_Qty']?></td>
			<td width="60" align="right"><?=$row['stock']?></td>
			<td width="95"><?=$row['L_StkIn_Date']?></td>
			<td width="95"><?=$row['L_StkOut_Date']?></td>
			<td width="95"><?=$row['St_Rev_Date']?></td>
			<td width="120">
<?php
			//ロケーション取得
			$SQL="SELECT Location FROM location_master 
			where Cust_CD='{$row['Assy_Cust_CD']}' and Parts_No='{$row['Assy_No']}';";
			if($result2=mysqli_query($link,$SQL))
			{
				while($row2= mysqli_fetch_assoc($result2))
				{
					echo $row2['Location'];
				}
			}
?>
</td>
			<td width="320">
<?php
			//仕掛状況取得
			$PROD_STAT="";
			$SQL="SELECT Req_Due_Date,Prod_Plan_Qty FROM productplan_table 
			where Cust_CD='{$row['Assy_Cust_CD']}' and Prod_No='{$row['Assy_No']}' and Comp_FG!=1;";
			if($result1=mysqli_query($link,$SQL))
			{
				while($row1= mysqli_fetch_assoc($result1))
				{
					if(empty($PROD_STAT))
					{ 
						$PROD_STAT=date("m-d",strtotime($row1['Req_Due_Date']))."/".$row1['Prod_Plan_Qty'];
					}
					else
					{
						$PROD_STAT=$PROD_STAT." ".date("m-d",strtotime($row1['Req_Due_Date']))."/".$row1['Prod_Plan_Qty'];	
					}
				}
				echo $PROD_STAT;
			}			
?>
			</td>
			</tr>			
<?php	
		cool_component($row['Assy_Cust_CD'],$row['Assy_No'],$space); 
		}
		mysqli_free_result($result);
	}
}
$space=-1;
cool_component($Cust_CD_Search,$Prod_No_Search,$space);

?>
</table>
<?php 
}
?>
</center>
</html>