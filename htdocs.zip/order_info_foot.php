<html>
<body bgcolor="#bbbbff">
<center>
<?php
if(!empty($_POST["Cust_CD_Search"]) and $_POST["Prod_No_Search"]!="")
{
	$Cust_CD_Search=$_POST["Cust_CD_Search"];
	$Prod_No_Search=$_POST["Prod_No_Search"];	

	//��`�t�@�C���̓Ǎ�
	//MySQL�ڑ��p�萔�̓Ǎ�
	require_once('config.php');



$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

if(!$link)
{
	die('�f�[�^�x�[�X�̐ڑ��Ɏ��s���܂����B');	
}
?>
<head charset="shift-JIS">
<table border="1" bgcolor="#999999">

<?php 
$DAY=Date('Y-m-d',strtotime("- 3 month"));
$SQL="SELECT * FROM order_master 
where Cust_CD='$Cust_CD_Search' and Prod_No='$Prod_No_Search' and Delv>'$DAY' 
ORDER BY Delv DESC;";
if($result=mysqli_query($link,$SQL))
{
	while($row = mysqli_fetch_assoc($result)) 
	{
?>
	<tr bgcolor="#ffffff">
		<td width="110"><?=$row['Order_No']?></td>
		<td width="75"><?=$row['Job_No']?></td>
		<td width="100"><?=$row['Delv']?></td>
		<td width="60" align="right"><?=$row['Order_Qty']?></td>
		<td width="60" align="right">
<?php
		if($row['Order_Qty']-$row['Delv_Qty']!=0)
		{
			echo $row['Order_Qty']-$row['Delv_Qty'];
		}
		?></td>
		<td width="100"><?=$row['Ship_Prep_Date']?></td>
		<td width="50"><?=$row['Delv_Point']?></td>
		<td width="60"><?=$row['Fol_Proc']?></td>
		<td width="100"><?=$row['Entry_Date']?></td>
	</tr>
<?php 
	}
?>
</table>
<?php 
	mysqli_free_result($result);
}
}
?>
</center>
</html>