<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./main.css">
</head>
<body>
    <div class="print_page">
    <?php 
        require_once("../config/config.php")
    ?>
    <div class="heading_form">
        <h1 class="heading">図面検索</h1> 
        <form class="form" action="index.php" method="GET">
            <div class="header_search">
                <input type="text" class="search_input" name="productName" placeholder="入力してください">
                <button type="Submit" value="searchValue" class="search_input_btn">検索</button>
            </div>
        </form>
    </div>
    <?php 
        $mysqli = new mysqli(HOST_NAME_LOCAL,USERNAME_PROD,PASS_PROD,DB_NAME_DRAW) or die(mysqli_error($mysqli));
        $product = $_GET['productName'];
        $query = $mysqli->query("SELECT * FROM `document`.`drawing_master` WHERE `Title` like '%$product%' AND `Activate` = 'True' LIMIT 100") or die(mysqli_error($mysqli));
    ?>
    <?php if ($query->num_rows==0) : ?>
        <H2 class="heading_back">見つかりませんでした！</H2>
    <?php else : ?>
     <table border="1">
         <thead>
             <tr>
                <th>ID （ずめん) </th>
                <th>図面番号</th>
                <th>名称</th>
                <th>設変</th>
                <th>得意先</th>
                <th>登録日</th>
                <th>更新日</th>
             </tr>
         </thead>
         <tbody>
            <?php while ($row = $query->fetch_assoc()):?>
                <tr>
                    <td><a href="<?=DRAWING_PATH.$row['FileName']?>.<?=$row['Prefix']?>" class="draw_of_yourLink"target="_bank"><?php echo $row['Id']?></a></td>
                    <td><?php echo $row['Title']?></td>
                    <td><?php echo $row['ExtProdName']?></td>
                    <td><?php echo $row['ExtChgNo']?></td>
                    <td><?php echo $row['ExtCustCd']?></td>
                    <td><?php echo $row['AddDate']?></td>
                    <td><?php echo $row['UpdateDate']?></td>
                </tr>
            <?php endwhile;?>
         </tbody>
     </table>
    <?php endif; ?>
    </div>
</body>
<footer>
    <p>Copyrighted of VIET(TM) 2021-2021</p>
</footer>
</html>