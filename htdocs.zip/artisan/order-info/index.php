<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>製品受注状況</title>
</head>
<body>
    <!-- imports -->
    <?php 
        require_once("../config/config.php")
    ?>
    <center>
    <!-- search form -->
    <h3 class="page-title"> 製品受注状況 </h3>
    <div class="search-form">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="get">
            得意先 : <input type="text" class="customer-code" autofocus name="customerCode" value= <?php if (isset($_GET['customerCode'])) {
                                                                            echo $_GET['customerCode'];
                                                                            }else echo'';?> >
            製品番号 : <input type="text" class="product-code" autofocus name="productCode" value= <?php if (isset($_GET['productCode'])) {
                                                                            echo $_GET['productCode'];
                                                                            }else echo'';?> >
        
            <input type="submit" value="検索">
        </form>
    </div>
    <!-- search result -->
    <?php if(isset($_GET['customerCode'])&& isset($_GET['productCode'])):?>
        <?php
        $monthsPrior = Date("Y-m-d", strtotime("- 3 month"));
        $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
        $productCode = strtoupper(trim($_GET['productCode']));
        $customerCode = trim($_GET['customerCode']);
        $result = $mysqli->query("SELECT * FROM order_master 
            WHERE Cust_CD = '$customerCode' AND Prod_No = '$productCode' AND Delv>'$monthsPrior'
            ORDER BY Delv DESC") or die(mysqli_error($mysqli))
        ?>
        <?php if ($result->num_rows == 0):?>
            <p>見つかりません。</p>
        <?php else:?>
            <table>
                <thead>
                    <tr>
                        <th>注番</th>
                        <th>工事番号</th>
                        <th>納期</th>
                        <th>受注数</th>
                        <th>未納数</th>
                        <th>納入日</th>
                        <th>納場</th>
                        <th>次工程</th>
                        <th>登録日</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()):?>
                        <tr>
                            <td><?php echo $row['Order_No']?></td>
                            <td><?php echo $row['Job_No']?></td>
                            <td><?php echo $row['Delv']?></td>
                            <td><?php echo $row['Order_Qty']?></td>
                            <td><?php if ($row['Order_Qty']-$row['Delv_Qty']>0) {
                                echo $row['Order_Qty']-$row['Delv_Qty'];
                                } else echo '';?></td>
                            <td><?php echo $row['Ship_Prep_Date']?></td>
                            <td><?php echo $row['Delv_Point']?></td>
                            <td><?php echo $row['Fol_Proc']?></td>
                            <td><?php echo $row['Entry_Date']?></td>
                            
                        </tr>
                    <?php endwhile;?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?> 
    </center>
</body>
</html>