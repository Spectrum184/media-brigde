<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>入出庫履歴込</title>
</head>

<body>
    <?php
    require_once("../config/config.php");
    ?>
    <center class="print-page">
        <h3 class="page-title">＜入出庫履歴＞</h3>
        <form method="GET" action="./index.php" class="form-search">
            <div class="search-bar">
                <div class="search-content">
                    <p>得意先CD:</p>
                    <input name="customerCode" class="customer-input" value=<?php if (isset($_GET['customerCode'])) {
                                                                                echo $_GET['customerCode'];
                                                                            } else {
                                                                                echo '';
                                                                            } ?>>
                </div>
                <div class="search-content">
                    <p>製品番号:</p>
                    <input name="productCode" autofocus value=<?php if (isset($_GET['productCode'])) {
                                                                    echo $_GET['productCode'];
                                                                } else {
                                                                    echo '';
                                                                } ?>>
                </div>
                <button type="submit">検索</button>
            </div>
        </form>
        <?php if (isset($_GET['customerCode']) && isset($_GET['productCode'])) : ?>
            <div class="table-result">
                <?php
                $customerCode = $_GET['customerCode'];
                $productCode = $_GET['productCode'];
                $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
                $result = $mysqli->query("SELECT * FROM stock_record_table WHERE Cust_CD='$customerCode' AND Prod_Parts_No='$productCode' ORDER BY Record_Time DESC;")
                ?>
                <?php if ($result->num_rows > 0) : ?>
                    <table>
                        <thead>
                            <tr>
                                <th>処理時間</th>
                                <th>得意</th>
                                <th>製品/部品番号</th>
                                <th>処理区</th>
                                <th>入出区</th>
                                <th>数量</th>
                                <th>当在庫</th>
                                <th>得意先コード</th>
                                <th>製品/部品番号</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()) : ?>
                                <tr>
                                    <td><?php
                                        $recordTime = substr($row['Record_Time'], 0, 16);
                                        echo $recordTime;
                                        ?>
                                    </td>
                                    <td><?php echo $row['Cust_CD'] ?></td>
                                    <td> <?php echo $row['Prod_Parts_No'] ?></td>
                                    <td><?php
                                        if ($row['Proc_Div'] == 'U') {
                                            echo '出荷';
                                        } elseif ($row['Proc_Div'] == 'I') {
                                            echo '入出庫';
                                        } elseif ($row['Proc_Div'] == 'Z') {
                                            echo '在庫調';
                                        }
                                        ?></td>
                                    <td><?php
                                        if ($row['In_Out_Div'] == 'I') {
                                            echo '入庫';
                                        } elseif ($row['In_Out_Div'] == 'O') {
                                            echo '出庫';
                                        }
                                        ?></td>
                                    <td> <?php echo $row['In_Out_Qty'] ?></td>
                                    <td> <?php echo $row['Thattime_Stock'] ?></td>
                                    <td><?php echo $row['R_Cust_CD'] ?></td>
                                    <td><?php echo $row['R_Prod_Parts_No'] ?></td>
                                </tr>
                            <?php endwhile ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <center>
                        <h5 style="font-weight: 400;">入出庫履歴がありません！</h5>
                    </center>
                <?php endif ?>
            </div>
        <?php endif ?>
        </div>
</body>

</html>