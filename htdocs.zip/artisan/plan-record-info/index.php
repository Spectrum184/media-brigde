<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>製作指示状況＆履歴</title>
</head>

<body>
    <?php
    require_once("../config/config.php")
    ?>
    <center class="print-page">
        <h3 class="page-title">＜製作指示状況＆履歴＞</h3>
        <form method="GET" action="./index.php">
            <div class="search-bar">
                <div class="search-content">
                    <p>得意先CD:</p>
                    <input name="customerCode" class="customer-input" value=<?php if (isset($_GET['customerCode'])) {
                                                                                echo $_GET['customerCode'];
                                                                            } else {
                                                                                echo '';
                                                                            } ?>>
                </div>
                <div class="search-content">
                    <p>製品番号:</p>
                    <input name="productCode" autofocus value=<?php if (isset($_GET['productCode'])) {
                                                                    echo $_GET['productCode'];
                                                                } else {
                                                                    echo '';
                                                                } ?>>
                </div>
                <button type="submit">検索</button>
            </div>
        </form>
        <div class="record-content">
            <?php if (isset($_GET['customerCode']) && isset($_GET['productCode'])) : ?>
                <?php
                $customerCode = $_GET['customerCode'];
                $productCode = $_GET['productCode'];
                $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
                $planNumber = '';
                $arrData = array();
                $arrTmp = array();

                // fill data for table 1
                $result1 = $mysqli->query("SELECT Prod_Parts_Name,stock,L_StkIn_Date,L_StkOut_Date FROM product_parts_master 
                LEFT JOIN unitsinstock_table ON unitsinstock_table.Cust_CD=product_parts_master.Cust_CD AND Prod_Parts_No=Prod_No AND Prod_Div='0' 
                WHERE product_parts_master.Cust_CD='$customerCode' AND Prod_Parts_No='$productCode';");

                // fill data for table 2
                $result2 = $mysqli->query("SELECT Abbre_Proc_Name FROM prod_process_master LEFT JOIN process_master 
                ON prod_process_master.Proc_CD=process_master.Proc_CD 
                WHERE Cust_CD='$customerCode' and Parts_No='$productCode';");

                //fill data for plan process
                $result3 = $mysqli->query("SELECT PT.Prod_Plan_No AS PP_No,Entry_Date,PT.Comp_FG AS PTC_FG,Seq_No,Abbre_Proc_Name,PTD.Prod_Plan_Qty AS PTD_PP_QTY,
                PTD.Req_Due_Date AS PTD_RD_DATE,
                PTD.Comp_Qty AS PTDC_QTY,PTD.Comp_Date AS PTDC_DATE,PTD.Comp_FG AS PTDC_FG FROM ((productplan_table AS PT
                LEFT JOIN (SELECT Prod_Plan_No,MAX(PRNT_FG) AS PTPC_FG FROM productplan_details_table GROUP BY Prod_Plan_No) AS PTP
                ON PT.Prod_Plan_No=PTP.Prod_Plan_No)
                LEFT JOIN productplan_details_table AS PTD ON PT.Prod_Plan_No=PTD.Prod_Plan_No)
                LEFT JOIN process_master AS PM ON PTD.Proc_CD=PM.Proc_CD
                WHERE Cust_CD='$customerCode' AND Prod_No='$productCode' AND PTPC_FG=1
                ORDER BY PP_No DESC;");

                while ($row = $result3->fetch_assoc()) {
                    if ($planNumber == '' || $planNumber == $row['PP_No']) {
                        array_push($arrTmp, $row);
                        $planNumber =  $row['PP_No'];
                    } else {
                        array_push($arrData, $arrTmp);
                        $arrTmp = array();
                        array_push($arrTmp, $row);
                        $planNumber =  $row['PP_No'];
                    }
                }

                ?>

                <?php if ($result1->num_rows > 0) : ?>
                    <div class="table-first">
                        <table>
                            <tbody>
                                <?php while ($row = $result1->fetch_assoc()) : ?>
                                    <td bgcolor="#cccccc" width="80">部品名称</td>
                                    <td bgcolor="#ffffff" width="200"><?= $row['Prod_Parts_Name'] ?></td>
                                    <td bgcolor="#cccccc" width="40">在庫</td>
                                    <td bgcolor="#ffffff" width="60" align="right"><?= $row['stock'] ?></td>
                                    <td bgcolor="#cccccc" width="80">最終入庫</td>
                                    <td bgcolor="#ffffff" width="90"><?= $row['L_StkIn_Date'] ?></td>
                                    <td bgcolor="#cccccc" width="80">最終出庫</td>
                                    <td bgcolor="#ffffff" width="90"><?= $row['L_StkOut_Date'] ?></td>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                <div class="table-second">
                    <table class="table-second">
                        <tbody>
                            <td bgcolor="#cccccc">現加工工程</td>
                            <?php if ($result2->num_rows > 0) : ?>
                                <?php while ($row = $result2->fetch_assoc()) : ?>
                                    <td bgcolor="#ffffff" width="100"><?= $row['Abbre_Proc_Name'] ?></td>
                                <?php endwhile; ?>
                            <?php else : ?>
                                <td bgcolor="#ffffff" width="100">未定義</td>
                            <?php endif ?>
                        </tbody>
                    </table>
                </div>
                <div class="table-third">
                    <table style="border: none;">
                        <tr style="background-color:#cccccc">
                            <td style="border:none; background-color:#00ff7f;">加工要期</td>
                            <td style="border:none; background-color:#00ff7f;">加工指示数</td>
                            <td style="border:none; background-color:#ffb6c1;">実加工日</td>
                            <td style="border:none; background-color:#ffb6c1;">実加工数</td>
                            <td style="border:none; background-color:#ff0000;">取消</td>
                        </tr>
                    </table>
                </div>
                <div class="table-group">
                    <?php if (count($arrData) > 0) : ?>
                        <?php foreach ($arrData as $item) : ?>
                            <div class="table-group-list">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td class="table-header">
                                                指示No日
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="background-color: #ffffe0;"><?php echo $item[0]['PP_No'] ?></td>
                                        </tr>
                                        <tr>
                                            <td style="background-color: #ffffe0;"><?php echo $item[0]['Entry_Date'] ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php foreach ($item as $element) : ?>
                                    <table>
                                        <tbody>
                                            <tr class="table-header">
                                                <td>
                                                    工程 <?php echo $element['Seq_No'] ?>
                                                </td>
                                                <td>
                                                    <?php echo $element['Abbre_Proc_Name'] ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#00ff7f"><?php echo $element['PTD_RD_DATE'] ?></td>
                                                <?php if ($element['PTDC_FG'] == '1') : ?>
                                                    <td bgcolor="#ffb6c1"><?php echo $element['PTDC_DATE'] ?></td>
                                                <?php else : ?>
                                                    <?php if ($element['PTC_FG'] != '1') : ?>
                                                        <td bgcolor="#ffffff"></td>
                                                    <?php else : ?>
                                                        <td bgcolor="#ff0000"></td>
                                                    <?php endif; ?>
                                                <?php endif ?>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#00ff7f"><?php echo $element['PTD_PP_QTY'] ?></td>
                                                <?php if ($element['PTDC_FG'] == '1') : ?>
                                                    <td bgcolor="#ffb6c1"><?php echo $element['PTDC_QTY'] ?></td>
                                                <?php else : ?>
                                                    <?php if ($element['PTC_FG'] != '1') : ?>
                                                        <td bgcolor="#ffffff"></td>
                                                    <?php else : ?>
                                                        <td bgcolor="#ff0000"></td>
                                                    <?php endif; ?>
                                                <?php endif ?>
                                            </tr>
                                        </tbody>
                                    </table>
                                <?php endforeach; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </center>
</body>

</html>