<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>MFTBC内示</title>
</head>
<body>
    <!-- imports -->
    <?php 
        require_once('../config/config.php')
    ?>
    <center>
    <!-- search form -->
    <h3 class="page-title"> MFTBC内示 </h3>
    <div class="search-form">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="get">
            製品番号 : <input type="text" class="product-code" autofocus name="productCode" value= <?php if (isset($_GET['productCode'])) {
                                                                            echo $_GET['productCode'];
                                                                            }else echo'';?> >
        
            <input type="submit" value="検索">
        </form>
    </div>
    <!-- query result -->
    <?php if(isset($_GET['productCode'])):?>
        <?php 
        $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
        $productCode = strtoupper(trim($_GET['productCode']));
        $result = $mysqli->query("SELECT * FROM mftbc_forecast WHERE Prod_No LIKE '%$productCode%' ") or die(mysqli_error($mysqli));
        ?> 
        <?php if($result->num_rows==0):?>
            <p><?php echo $productCode ?>見つかりません。</p>
        <?php else :?>
            <table>
                <thead >
                    <tr>
                        <th>製品番号</th>
                        <th>部品名称</th>
                        <th>納場</th>
                        <th>次工程</th>
                        <th>予定数</th>
                        <th>予定納入日</th>
                        <th>納入時期</th>
                        <th>受注確定</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()):?>
                        <tr>
                            <td><?php echo $row['Prod_No'] ?></td>
                            <td><?php echo $row['Prod_Name'] ?></td>
                            <td><?php echo $row['Delv_Point'] ?></td>
                            <td><?php echo $row['Fol_Proc'] ?></td>
                            <td><?php echo $row['Fcst_Qty'] ?></td>
                            <td><?php echo $row['Fcst_Delv'] ?></td>
                            <td><?php echo $row['Fcst_Season'] ?></td>
                            <td><?php echo $row['Order_Comfirm'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?>

    </center>

</body>
</html>