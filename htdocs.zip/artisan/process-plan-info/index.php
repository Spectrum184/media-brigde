<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>工程別指示状況</title>
</head>
<body>
    <!-- imports -->
    <?php 
        require_once("../config/config.php")
    ?>
    <center>
    <!-- search form -->
    <h3 class="page-title"> ＜工程別指示状況＞ </h3>
    <div class="search-form">
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="get">
        加工先: <input type="text" class="process-code" autofocus name="processCode" value= <?php if (isset($_GET['processCode'])) {
                                                                            echo $_GET['processCode'];
                                                                            }else echo'';?> >
        <input type="submit" value="検索">
        </form>
    </div>
    <!-- search result -->
    <?php if(isset($_GET['processCode'])): ?>
        <?php 
            $today = date("Y-m-d");
            $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
            $processCode = trim($_GET['processCode']);
            $result = $mysqli->query("SELECT PDT.Prod_Plan_No as productPlan, Seq_No as sequenceNumber, PT.Cust_CD as customerCode, Prod_No as productCode,
                Prod_Parts_Name as productName, Abbre_Proc_Name as abbreviateName, PDT.Prod_Plan_Qty as planQuantity,
                PDT.Req_Due_Date as requestDate, PDT.Comp_Qty as completeQuantity, PDT.Comp_Date as completeDate,
                PDT.Comp_FG as completed FROM productplan_details_table as PDT
                LEFT JOIN productplan_table as PT ON PDT.Prod_Plan_No=PT.Prod_Plan_No
                LEFT JOIN process_master AS PM ON PDT.Proc_CD=PM.Proc_CD
                LEFT JOIN product_parts_master AS PPM ON PPM.Cust_CD=PT.Cust_CD and Prod_Parts_No=Prod_No
                WHERE PDT.Proc_CD=$processCode and ((PT.Comp_FG=0 and PDT.Comp_FG=0) or PDT.Comp_Date=2021-09-09)
                ORDER BY requestDate") or die(mysqli_error($mysqli));
        ?>
        <?php if($result->num_rows==0) :?>
            <p>加工先<?php echo $processCode?>が見つかりません。</p>
        <?php else: ?>
        <table>
            <thead>
                <th>製作指示番号</th>
                <th>得意先</th>
                <th>製品/部品番号</th>
                <th>名称</th>
                <th>工程</th>
                <th>製作要期</th>
                <th>指示数</th>
                <th>状態</th>
                <th>不足日</th>
                <th>完了日</th>
                <th>完成数</th>
            </thead>
            <tbody>
                <?php while($row= $result->fetch_assoc()):?>
                    <?php 
                        // search out of stock date
                        $searchTable = '';
                        if ($row['customerCode']==5001){
                            $searchTable = 'wt_calc_parts_mftbc';
                        } else if ($row['customerCode']==5017) $searchTable = 'wt_calc_parts_hitachi';
                        $productCode = $row['productCode'];
                        $outOfStockDate = '';
                        if ($searchTable != ''){
                            $result2 = $mysqli->query("SELECT order_deadline FROM $searchTable
                                WHERE product_code = '$productCode' AND short_quantity > 0 
                                LIMIT 1") or die(mysqli_error($mysqli));
                            if ($result2->num_rows>0){
                                while($row2= $result2->fetch_assoc()){
                                    $outOfStockDate = $row2['order_deadline'];
                                }
                            } else $outOfStockDate = "3ヶ月以外";
                        } else $outOfStockDate = "データ無し";

                        // search work status
                        $workStatus = '';
                        if ($row['completed']==1){
                            $workStatus = "加工完";
                        } else
                        {
                            if ($row['sequenceNumber']>1){
                                $productPlan = $row['productPlan'];
                                $previousSequence = $row['sequenceNumber']-1;
                                $result3 = $mysqli->query("SELECT Comp_FG FROM productplan_details_table 
                                    WHERE Prod_Plan_No = '$productPlan' AND Seq_No = $previousSequence") or die(mysqli_error($mysqli));
                                while($row3= $result3->fetch_assoc()){
                                    if ($row3['Comp_FG']==1) {
                                        $workStatus = "加工可";
                                    } else $workStatus = "前工未";
                                }
                            }
                        }
                    ?>
                    <tr class=<?php if($row['completed']==1){
                                    echo "row-complete";
                                }else{
                                    if (strtotime($today)>strtotime($row['requestDate'])) {
                                        echo "row-late";
                                    }}?> >
                        <td><?php echo $row['productPlan']?></td>
                        <td><?php echo $row['customerCode']?></td>
                        <td><?php echo $row['productCode']?></td>
                        <td><?php echo $row['productName']?></td>
                        <td><?php echo $row['abbreviateName']?></td>
                        <td><?php echo $row['requestDate']?></td>
                        <td><?php echo $row['planQuantity']?></td>
                        <td><?php echo $workStatus?></td>
                        <td><?php echo $outOfStockDate?></td>
                        <td><?php echo $row['completeDate']?></td>
                        <td><?php echo $row['completeQuantity']?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php endif; ?>
    <?php endif; ?>
    </center>
</body>
</html>