<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>構成品在庫状況</title>
</head>
<body>
    <!-- imports -->
    <?php 
        require_once('../config/config.php')
    ?>
    <center>
        <!-- search form -->
    <h3 class="page-title"> <構成品在庫状況> </h3>
    <div class="search-form">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="get">
            得意先コード : <input type="text" class="customer-code" name="customerCode" value= <?php if (isset($_GET['customerCode'])) {
                                                                                echo $_GET['customerCode'];
                                                                                }else echo'';?> >
        
            製品番号 : <input type="text" class="product-code" name="productCode" value= <?php if (isset($_GET['productCode'])) {
                                                                            echo $_GET['productCode'];
                                                                            }else echo'';?> >
        
            <input type="submit"  value="検索">
        </form>
    </div>
    <!-- product information -->
    <?php if (isset($_GET['productCode'])) : ?>
        <?php
        $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
        $customerCode = trim($_GET['customerCode']);
        $productCode = strtoupper(trim($_GET['productCode']));
        //search for the product's storage status
        $result1 = $mysqli->query("SELECT Prod_Parts_No,Prod_Parts_Name,stock,L_StkIn_Date,L_StkOut_Date, St_Rev_Date FROM product_parts_master 
        LEFT JOIN unitsinstock_table ON unitsinstock_table.Cust_CD=product_parts_master.Cust_CD AND Prod_Parts_No=Prod_No AND Prod_Div='0' 
        where product_parts_master.Cust_CD='$customerCode' and Prod_Parts_No='$productCode';");

        // search for the product's location

        $result2 = $mysqli->query("SELECT * FROM product_location WHERE Pro_No='$productCode';");
        $queryTable ='';
        if ($customerCode =="5001") {
            $queryTable ='wt_calc_parts_mftbc';
        } elseif($customerCode =="5017"){
            $queryTable ='wt_calc_parts_hitachi';
        }

        $PROD_STAT = '';
        ?>
        <?php if ($result1->num_rows == 0) : ?>
                <div class="result-notify"><?php echo "この製品番号は製品に対応しません！" ?></div>
        <?php else : ?>
            <?php while ($row1 = $result1->fetch_assoc()) : ?>
                <table style='margin: 1px solid black'>
                    <thead>
                        <tr>
                            <th>製品番号</th>
                            <td><?php echo $row1['Prod_Parts_No'] ?></td>
                            <th>部品名称</th>
                            <td><?php echo $row1['Prod_Parts_Name'] ?></td>
                            <th>在庫</th>
                            <td><?php echo $row1['stock'] ?></td>
                            <th>最終入庫</th>
                            <td><?php echo $row1['L_StkIn_Date'] ?></td>
                            <th>最終出庫</th>
                            <td><?php echo $row1['L_StkOut_Date'] ?></td>
                            <th>最終在庫調整</th>
                            <td><?php echo $row1['St_Rev_Date'] ?></td>
                            <th>不足日</th>
                            <td>
                                <?php 
                                    if ($row1['stock']<0){
                                        echo "在庫不足";
                                    } else
                                    {if ($queryTable!=''){
                                        $result8 = $mysqli->query("SELECT order_deadline FROM $queryTable 
                                        WHERE product_code = '$productCode' AND short_quantity>0
                                        LIMIT 1;") or die(mysqli_error($mysqli));
                                        if ($result8->num_rows>0) {
                                            while($row8 = $result8->fetch_assoc()){
                                                echo  $row8['order_deadline'] ;
                                            }
                                        } else {
                                            echo "3ヶ月以外";
                                        }
                                    }}
                                ?>
                            </td>
                            <th>保管</th>
                            <td>
                                <?php 
                                    while($row2 = $result2->fetch_assoc()){
                                        echo $row2['Building_No'] . $row2['Floor_No'] . $row2['Row_Locate'] . $row2['No_Locate'] . $row2['Shelf'];
                                        echo "<br>";
                                    }
                                ?>
                            </td>
                        </tr>
                    </thead>
                    
                </table>
            <?php endwhile;?>
        <?php endif;?>
        <!-- component(s) information -->
        <table>
            <thead>
                <tr>
                    <th>製品番号</th>
                    <th>部品名称</th>
                    <th>使用数</th>
                    <th>在庫</th>
                    <th>最終入庫</th>
                    <th>最終出庫</th>
                    <th>最終在庫調整</th>
                    <th>不足日</th>
                    <th>格納場所</th>
                    <th>完了工程</th>
                    <th>仕掛状況</th>
                </tr>
            </thead>
            <tbody>
                <?php function searchComponent($customerCode, $productCode, $flag) {
                        $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
                        $result3 = $mysqli->query("SELECT Parts_Cust_CD,Parts_No,Prod_Parts_Name,Product_div,Used_Qty,stock,L_StkIn_Date,L_StkOut_Date, St_Rev_Date FROM (component_master 
                        left join product_parts_master on Cust_CD=Parts_Cust_CD and Prod_Parts_No=Parts_No) 
                        left join unitsinstock_table on unitsinstock_table.Cust_CD=Parts_Cust_CD and Parts_No=Prod_No 
                        where Assy_Cust_CD='$customerCode' and Assy_No='$productCode';") or die(mysqli_error($mysqli));
                        if ($result3->num_rows > 0) {
                            $flag += 1;
                        }
                        while ($row3 = $result3->fetch_assoc()) {
                            $queryTable ='';
                            if ($customerCode =="5001") {
                                $queryTable ='wt_calc_parts_mftbc';
                            } elseif($customerCode =="5017"){
                                $queryTable ='wt_calc_parts_hitachi';
                            }
                            if (($row3['Product_div'] == "S2")) {
                                echo "<tr bgcolor='#FFFF00'>";
                            }

                            $space = $flag * 4;

                            if ($space === 0) {
                                echo "<td>" . $row3['Parts_No'] . "</td>";
                            } else {
                                echo "<td>";
                                while ($space > 0) {
                                    echo "&nbsp";
                                    $space = $space - 1;
                                }
                                echo  $row3['Parts_No'] . "</td>";
                            }

                            echo "<td>" . $row3['Prod_Parts_Name'] . "</td>";
                            echo "<td>" . $row3['Used_Qty'] . "</td>";
                            echo "<td>" . $row3['stock'] . "</td>";
                            echo "<td>" . $row3['L_StkIn_Date'] . "</td>";
                            echo "<td>" . $row3['L_StkOut_Date'] . "</td>";
                            echo "<td>" . $row3['St_Rev_Date'] . "</td>";

                            if ($row3['stock']< 0 ){
                                echo "<td>在庫不足</td>";
                            } else{
                                $result7 = $mysqli->query("SELECT order_deadline FROM $queryTable 
                                    WHERE product_code = '{$row3['Parts_No']}' AND short_quantity > 0 LIMIT 1");
                                if($result7->num_rows > 0){
                                    while($row7=$result7->fetch_assoc()){
                                        echo "<td>" . $row7['order_deadline'] . "</td>";
                                    }
                                } else {
                                    echo "<td>3ヶ月以外</td>";
                                }
                            }                               
                            
                            //search for the part's storage location
                            $result4 = $mysqli->query("SELECT Location FROM location_master 
                                WHERE Cust_CD='{$row3['Parts_Cust_CD']}' AND Parts_No='{$row3['Parts_No']}';");
                            if (isset($result4)) {
                                echo "<td>";
                                if ($result4->num_rows > 1) {
                                    while ($row4 = mysqli_fetch_assoc($result4)) {
                                        echo $row4['Location'];
                                        echo "<br>";
                                    }
                                } else {
                                    while ($row4 = mysqli_fetch_assoc($result4)) {
                                        echo $row4['Location'];
                                    }
                                }
                                echo "</td>";
                            }
                            $result5 = $mysqli->query("SELECT Abbre_Proc_name FROM prod_process_master AS ppm
                                    INNER JOIN (SELECT Cust_CD,Parts_NO,Max(Proc_No) AS MAX_P_NO FROM prod_process_master        
                                    GROUP BY Cust_CD,Parts_NO) AS s1 
                                    ON ppm.Cust_CD=s1.Cust_CD AND ppm.Parts_NO=s1.Parts_NO AND ppm.Proc_No=s1.MAX_P_NO        
                                    LEFT JOIN process_master ON ppm.Proc_CD=process_master.Proc_CD
                                    WHERE ppm.Cust_CD='{$row3['Parts_Cust_CD']}' AND ppm.Parts_NO='{$row3['Parts_No']}';");
                            if (isset($result5)) {
                                echo "<td>";

                                while ($row5 = $result5->fetch_assoc()) {
                                    echo $row5['Abbre_Proc_name'];
                                }

                                echo "</td>";
                            }
                            $result6 = $mysqli->query("SELECT Req_Due_Date,Prod_Plan_Qty FROM productplan_table 
                                    WHERE Cust_CD='{$row3['Parts_Cust_CD']}' AND Prod_No='{$row3['Parts_No']}' and Comp_FG!=1;");
                            if (isset($result6)) {
                                echo "<td>";
                                if ($result6->num_rows > 1) {
                                    while ($row6 = $result6->fetch_assoc()) {
                                        echo $row6['Req_Due_Date'] . " " . $row6['Prod_Plan_Qty'] . "<br>";
                                    }
                                } else {
                                    while ($row6 = $result6->fetch_assoc()) {
                                        echo $row6['Req_Due_Date'] . " " . $row6['Prod_Plan_Qty'];
                                    }
                                }
                                echo "</td>";
                            }
                            echo "</tr>";
                            if (isset($row3['Parts_No']))
                            searchComponent($customerCode, $row3['Parts_No'], $flag);
                        }
                    }
                    $flag = -1;
                    searchComponent($customerCode, $productCode, $flag);
                ?>
            </tbody>
        </table>
    <?php endif;?>
    </center>
</body>
</html>