<?php
session_start();
//host name
define('HOST_NAME_LOCAL', 'localhost');
//define('HOST_NAME_ZUMEN', 'ZUMENSERVER-HP');
define('HOST_NAME_ZUMEN', 'localhost');

// database name
define('DB_NAME_DRAW', "document");
define('DB_NAME_PROD', "spin");
define('DB_NAME_PROD_ZUMEN', "production_control");

// username
define('USERNAME_PROD', 'root');
define('USERNAME_TEST', 'root');

//password
define('PASS_PROD', "thanh1804");
define('PASS_TEST', "thanh1804");

// path of drawing folder
// define("DRAWING_PATH", "//ZUMENSERVER-HP/document/");
define("DRAWING_PATH", "//SERVER01/document/");

// path of indentify picture folder
// define('IDENTIFY_PIC_PATH', '//ZUMENSERVER-HP/identify/');
define('IDENTIFY_PIC_PATH', '//SERVER01/identify/');

// $path is the path to the pdf file
function showPDF($path)
{
    if ($path) {
        header("Content-type: application/pdf");
        header("Content-Disposition: inline; filename=filename.pdf");
        @readfile($path);
    }
}
