﻿<html>
<body bgcolor="#bbbbff">
<center>
<form method="post" action="component_info_head.php" target="head">
<font size=5>＜構成品在庫状況＞</font><br>
得意先CD<input type="text" value="<?php 
if(!empty($_POST["Cust_CD_Search"]))
{
	echo $_POST["Cust_CD_Search"];
}
?>" name="Cust_CD_Search" size="4">&nbsp;
製品番号<input type="text" value="<?php 
if(!empty($_POST["Prod_No_Search"]))
{
	echo $_POST["Prod_No_Search"];
}
?>" name="Prod_No_Search" size="30">
<input type="submit" value="検索">
</form>

<?php
if(!empty($_POST["Cust_CD_Search"]) and $_POST["Prod_No_Search"]!="")
{
	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');
	$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);
	if(!$link)
	{
		die('データベースの接続に失敗しました。');	
	}

	$SQL="SELECT Prod_Parts_Name,stock,L_StkIn_Date,L_StkOut_Date FROM product_parts_master 
	left join unitsinstock_table on unitsinstock_table.Cust_CD=product_parts_master.Cust_CD and Prod_Parts_No=Prod_No and Prod_Div='0' 
	where product_parts_master.Cust_CD='{$_POST["Cust_CD_Search"]}' and Prod_Parts_No='{$_POST["Prod_No_Search"]}';";
	if($result=mysqli_query($link,$SQL))
	{
		if(mysqli_num_rows($result)!=0)
		{
			$row = mysqli_fetch_assoc($result)
?>

			<table border="1" bgcolor="#999999">
			<tr>
				<td bgcolor="#cccccc" width="80">部品名称</td>
				<td bgcolor="#ffffff" width="220"><?=$row['Prod_Parts_Name']?></td>
				<td bgcolor="#cccccc" width="40">在庫</td>
				<td bgcolor="#ffffff" width="60" align="right"><?=$row['stock']?></td>
				<td bgcolor="#cccccc" width="80">最終入庫</td>
				<td bgcolor="#ffffff" width="90"><?=$row['L_StkIn_Date']?></td>
				<td bgcolor="#cccccc" width="80">最終出庫</td>
				<td bgcolor="#ffffff" width="90"><?=$row['L_StkOut_Date']?></td>
				<td bgcolor="#cccccc" width="80">仕掛状況</td>
				<td bgcolor="#ffffff" width="320">
				
<?php
			//仕掛状況取得
			$PROD_STAT="";
			$SQL="SELECT Req_Due_Date,Prod_Plan_Qty FROM productplan_table 
			where Cust_CD='{$_POST["Cust_CD_Search"]}' and Prod_No='{$_POST["Prod_No_Search"]}' and Comp_FG!=1;";
			if($result1=mysqli_query($link,$SQL))
			{
				while($row1= mysqli_fetch_assoc($result1))
				{
					if(empty($PROD_STAT))
					{ 
						$PROD_STAT=date("m-d",strtotime($row1['Req_Due_Date']))."/".$row1['Prod_Plan_Qty'];
					}
					else
					{
						$PROD_STAT=$PROD_STAT." ".date("m-d",strtotime($row1['Req_Due_Date']))."/".$row1['Prod_Plan_Qty'];	
					}
				}
				echo $PROD_STAT;
			}			
?>
			</td>
			</tr>
			</table>

			<head charset="shift-JIS">
			<table border="1" bgcolor="#999999">
			<tr bgcolor="#cccccc">
				<td width="200"><b>部品番号</b></td>
				<td width="220">部品名称</td>
				<td width="60">使用数</td>
				<td width="60">在庫</td>
				<td width="90">最終入庫</td>
				<td width="90">最終出庫</td>
				<td width="120">格納場所</td>
				<td width="120">完了工程</td>
				<td width="320">仕掛状況</td>
			</tr>
			</table>
<?php
		}
		else
		{
			echo'データが見つかりません。';
		}
	}
}
?>

	<body onLoad="document.formName.submit();">

	<form method="post" action="component_info_foot.php" target="foot" name="formName">
	<input type="hidden" name="Cust_CD_Search" value="<?php echo $_POST["Cust_CD_Search"]; ?>">
	<input type="hidden" name="Prod_No_Search" value="<?php echo $_POST["Prod_No_Search"]; ?>">
	</form>

	</body>

</center>
</html>