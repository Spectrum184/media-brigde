﻿<html>
<body bgcolor="#bbbbff">
<head charset="Shift_JIS">
<title>加工票出力チェック</title>

<font size=6>＜加工票出力チェック＞</font><br><br>
<form method="post" action="prod_print_cheak.php">
製作指示No<input pattern="[0-9]{9}" title="[0-9]9文字" value="" name="Plan_No_Search" size="8" autofocus>
（バーコードを読込ませてください）<br><br>
</form>

<?php 
header("Content-Type: text/html;charset=utf8");
if(!empty($_POST["Plan_No_Search"]))
{
	$PNoS_array=str_split($_POST["Plan_No_Search"],8);

	$PPNO=$PNoS_array[0];
	$SEQ=$PNoS_array[1];

	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');
	$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

	if(!$link)
	{
?>
		<button onclick="location.href='prod_data_search.php'">戻る</button><br>
<?php
		//DB接続失敗の場合は処理を止める
		die('データベースの接続に失敗しました。<br />
		管理者へ連絡してください。');
	}


	
	$SQL="SELECT pt.Cust_CD AS PT_CCD,Prod_No,Seq_No,Proc_Name,pdt.Req_Due_Date AS PDT_Req_Due_Date,pdt.Prod_Plan_Qty AS PDT_Prod_Plan_Qty,
        Prod_Parts_Name,pdt.Comp_FG AS PDT_C_FG,pdt.PRNT_FG AS PDT_P_FG FROM productplan_details_table as pdt
 
	left join productplan_table as pt on pt.Prod_Plan_No=pdt.Prod_Plan_No
 
	left join process_master as pm on pm.Proc_CD=pdt.Proc_CD
 
	left join product_parts_master as ppm on ppm.Cust_CD=pt.Cust_CD and ppm.Prod_Parts_No=pt.Prod_No 
	where pdt.Prod_Plan_No='$PNoS_array[0]' and Seq_No=$PNoS_array[1] and Prod_No IS NOT NULL;";
	if($result=mysqli_query($link,$SQL))
	{
		if(mysqli_num_rows($result)!=0)
		{
			$row = mysqli_fetch_assoc($result);
?>
			<table border="1" bgcolor="#999999">
			<tr bgcolor="#cccccc">
				<td width="80"><b>得意CD</b></td>
				<td width="150"><b>製品・部品番号</b></td>
				<td width="200"><b>名称</b></td>
			</tr>
			<tr bgcolor="#ffff99">
				<td><?=$row['PT_CCD']?></td>
				<td><?=$row['Prod_No']?></td>
				<td><?=$row['Prod_Parts_Name']?></td>
			</tr>
			</table><br><br>
			<table border="1" bgcolor="#999999">
			<tr bgcolor="#cccccc">
				<td width="90"><b>工程</b></td>
				<td width="80"><b>指示納期</b></td>
				<td width="70"><b>指示数</b></td>
			</tr>
			<tr bgcolor="#ffff99">
				<td><?=$row['Proc_Name']?></td>
				<td><?=$row['PDT_Req_Due_Date']?></td>
				<td align="right"><?=$row['PDT_Prod_Plan_Qty']?></td>
			</tr>
			</table><br><br>
			<table border="1" bgcolor="#999999">
			<tr bgcolor="#cccccc">
				<td width="90"><b>前工程</b></td>
				<td width="80"><b>前完日</b></td>
				<td width="70"><b>前完数</b></td>
				<td width="90"><b>後工程</b></td>
			</tr>
			<tr bgcolor="#ffff99">
<?php 
			//前工程状態読込
			$SQL="SELECT Proc_Name,Prod_Plan_Qty,Req_Due_Date,Comp_Qty,Comp_Date,Comp_FG FROM productplan_details_table as pdt
			left join process_master as pm on pm.Proc_CD=pdt.Proc_CD
 
			where Prod_Plan_No='$PNoS_array[0]' and Seq_No=$PNoS_array[1]-1;"; 
			if($result=mysqli_query($link,$SQL))
			{
				//読込データの有無をチェック
				if(mysqli_num_rows($result)!=0)
				{
					$row1 = mysqli_fetch_assoc($result);
?>
					<td><?=$row1['Proc_Name']?></td>
					<td><?=$row1['Comp_Date']?></td>
					<td><?=$row1['Comp_Qty']?></td>
<?php
				}
				else
				{
?>
					<td>-</td>
					<td>-</td>
					<td>-</td>
<?php
				}
			}
			else
			{
				echo'前工程テータ読込失敗';
			}
			//後工程状態読込
			$SQL="SELECT Proc_Name FROM productplan_details_table as pdt
			left join process_master as pm on pm.Proc_CD=pdt.Proc_CD
 
			where Prod_Plan_No='$PNoS_array[0]' and Seq_No=$PNoS_array[1]+1;"; 
			if($result=mysqli_query($link,$SQL))
			{
				//読込データの有無をチェック
				if(mysqli_num_rows($result)!=0)
				{
					$row2 = mysqli_fetch_assoc($result);		
?>
					<td><?=$row2['Proc_Name']?></td>
<?php
				}
				else
				{
?>
					<td>-</td>
<?php
				}
			}
			else
			{
				echo'後工程テータ読込失敗';
			}
?>
			</tr>
			</table><br><br>
<?php
			if($row['PDT_C_FG']==1)
			{
				echo'入庫消込済みです。';
			}
			elseif($row['PDT_P_FG']==1)
			{
				echo'チェック済みです。';
			}
			else
			{
				$SQL="UPDATE productplan_details_table 
					SET PRNT_FG=1 
					where Prod_Plan_No='$PPNO' and Seq_No=$SEQ;";

					mysqli_query($link,$SQL);
				echo'チェックOK！！';
			}
		}
		else
		{
			echo'データが見つかりません。';
		}
 		mysqli_free_result($result);

	}
	else
	{
		echo'エラー';
	}
}


?>
</html>