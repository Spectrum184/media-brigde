﻿<html>
<body bgcolor="#bbbbff">
<center>
<form method="post" action="stock_record_info_foot.php" target="foot">
<font size=5>＜入出庫履歴＞</font><br>
得意先CD<input type="text" value="<?php 
if(!empty($_POST["Cust_CD_Search"]))
{
	echo $_POST["Cust_CD_Search"];
}
?>" name="Cust_CD_Search" size="4">&nbsp;
製品番号<input type="text" value="<?php 
if(!empty($_POST["Prod_No_Search"]))
{
	echo $_POST["Prod_No_Search"];
}
?>" name="Prod_No_Search" size="30">
<input type="submit" value="検索">
</form>


<head charset="shift-JIS">
<table border="1" bgcolor="#999999">
<tr bgcolor="#cccccc">
	<td width="160"><b>処理時間</b></td>
	<td width="65">得意CD</td>
	<td width="180">製品/部品番号</td>
	<td width="60">処理区</td>
	<td width="60">入出区</td>
	<td width="60">数量</td>
	<td width="60">当在庫</td>
	<td width="250">引当</td>
</tr>
</table>

</center>
</html>