﻿<html>
<body bgcolor="#bbbbff">
<center>
<?php
if(!empty($_POST["PROC_CD_Search"]))
{
	$PROC_CD_Search=$_POST["PROC_CD_Search"];	

	//定義ファイルの読込
	//MySQL接続用定数の読込
	require_once('config.php');



$link=mysqli_connect(HOST_NAME,USER_ID,PASS,DB_NAME_PROD);

if(!$link)
{
	die('データベースの接続に失敗しました。');	
}
?>
<head charset="shift-JIS">
<table border="1" bgcolor="#999999">

<?php
$TODAY=date("Y-m-d");

$SQL="SELECT PDT.Prod_Plan_No as PP_NO,Seq_No,PT.Cust_CD as C_CD,Prod_No,Prod_Parts_Name,Abbre_Proc_Name,PDT.Prod_Plan_Qty as PP_QTY,
PDT.Req_Due_Date as RD_DATE,
PDT.Comp_Qty as C_QTY,PDT.Comp_Date as C_DATE,PDT.Comp_FG as C_FG FROM productplan_details_table as PDT 

LEFT JOIN productplan_table as PT ON PDT.Prod_Plan_No=PT.Prod_Plan_No

LEFT JOIN process_master AS PM ON PDT.Proc_CD=PM.Proc_CD

LEFT JOIN product_parts_master AS PPM ON PPM.Cust_CD=PT.Cust_CD and Prod_Parts_No=Prod_No 
WHERE PDT.Proc_CD='$PROC_CD_Search' and ((PT.Comp_FG=0 and PDT.Comp_FG=0) or PDT.Comp_Date='$TODAY') 
ORDER BY RD_DATE;";
if($result=mysqli_query($link,$SQL))
{
	while($row = mysqli_fetch_assoc($result)) 
	{
		if($row['C_DATE']==$TODAY)
		{
?>
			<tr bgcolor="FFE4B5">
<?php
		}		
		elseif($row['RD_DATE']<$TODAY)
		{
?>
			<tr bgcolor="#ffff00">
<?php
		}
		else
		{
?>
			<tr bgcolor="#ffffff">
<?php
		}
?>
				<td width="110"><?=$row['PP_NO']?><?=$row['Seq_No']?></td>
				<td width="65"><?=$row['C_CD']?></td>
				<td width="180"><?=$row['Prod_No']?></td>
				<td width="200"><?=$row['Prod_Parts_Name']?></td>
				<td width="100"><?=$row['Abbre_Proc_Name']?></td>
				<td width="100"><?=$row['RD_DATE']?></td>
				<td width="60"  align="right"><?=$row['PP_QTY']?></td>
				<td width="60">
<?php
				if($row['C_FG']==1)
				{
					echo '加工完';
				}			
				elseif($row['Seq_No']==1)
				{
					echo '加工可';
				}
				else
				{
					$SQL="SELECT Comp_FG FROM productplan_details_table
					where Prod_Plan_No='{$row['PP_NO']}' and Seq_No={$row['Seq_No']}-1;";
					if($result1=mysqli_query($link,$SQL))
					{
						while($row1 = mysqli_fetch_assoc($result1))
						{
							if($row1['Comp_FG']==1)
							{
								echo '加工可';
							}
							else
							{
								echo '前工未';
							}						
						}
					}
				}								
?>
				</td>
				<td width="100"><?=$row['C_DATE']?></td>
				<td width="60" align="right"><?=$row['C_QTY']?></td>
			</tr>
<?php 
	}
?>
</table>
<?php 
	mysqli_free_result($result);
}
}
?>
</center>
</html>