﻿<html>
<body bgcolor="#bbbbff">
<center>
<form method="post" action="proc_plan_info_foot.php" target="foot">
<font size=5>＜工程別製作指示状況＞</font><br>
加工先CD<input type="text" value="<?php 
if(!empty($_POST["PROC_CD_Search"]))
{
	echo $_POST["PROC_CD_Search"];
}
?>" name="PROC_CD_Search" size="4">

<input type="submit" value="検索">
</form>


<head charset="shift-JIS">
<table border="1" bgcolor="#999999">
<tr bgcolor="#cccccc">
	<td width="110">製作指示No.</td>
	<td width="65">得意CD</td>
	<td width="180">製品/部品番号</td>
	<td width="200">名称</td>
	<td width="100">工程</td>
	<td width="100">製作要期</td>
	<td width="60">指示数</td>
	<td width="60">状態</td>
	<td width="100">完了日</td>
	<td width="60">完成数</td>
</tr>
</table>

</center>
</html>